library(testthat)
library(deeptime)

test_check("deeptime")
